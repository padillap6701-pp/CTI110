import turtle          
win = turtle.Screen()  
t = turtle.Turtle()

# --- Configuration ---
INITIAL_SIZE = 100
LOOP_RADIUS = 30
PEN_THICKNESS = 5

t.pensize(PEN_THICKNESS)
t.pencolor("purple")
t.speed(3)                 
t.setheading(90)

# Function to draw the letter 'P'
def draw_P(size, radius):
    t.forward(size)
    t.right(90)
    t.forward(radius) 
    t.circle(-radius, 180)
    t.forward(radius)
    t.setheading(270)
    t.penup()
    t.forward(size)
    t.setheading(0)
    t.pendown()


# --- Draw First Initial (P) ---
t.penup()
t.goto(-100, -50) 
t.pendown()
draw_P(INITIAL_SIZE, LOOP_RADIUS)

# --- Move for Second Initial ---
t.penup()
t.forward((2 * LOOP_RADIUS) + 20) 
t.setheading(90)
t.pendown()

draw_P(INITIAL_SIZE, LOOP_RADIUS)


win.mainloop()