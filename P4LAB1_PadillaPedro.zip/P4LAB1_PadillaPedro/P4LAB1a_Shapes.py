import turtle          
win = turtle.Screen()  
t = turtle.Turtle()

# --- Configuration ---
t.pensize(3)
t.shape("turtle")

# Function to draw a shape using a for loop
def draw_shape(sides, angle, color, length):
    t.pencolor(color)
    for _ in range(sides):
        t.forward(length)
        t.left(angle)

# --- Draw Square ---
t.penup()
t.goto(-100, 100)
t.pendown()
draw_shape(4, 90, "red", 100)

# --- Draw Triangle ---
t.penup()
t.goto(0, 0)
t.pendown()
draw_shape(3, 120, "blue", 100)

win.mainloop()